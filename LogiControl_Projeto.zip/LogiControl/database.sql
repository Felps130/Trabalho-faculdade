CREATE DATABASE IF NOT EXISTS logicontrol CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE logicontrol;

CREATE TABLE produtos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(120) NOT NULL,
 sku VARCHAR(40) UNIQUE NULL,
 categoria VARCHAR(80) NULL,
 peso DECIMAL(10,3) NOT NULL DEFAULT 0,
 estoque INT NOT NULL DEFAULT 0,
 descricao TEXT NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE enderecos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 identificacao VARCHAR(120) NOT NULL,
 tipo ENUM('Origem','Destino','Ambos') NOT NULL DEFAULT 'Ambos',
 cep VARCHAR(12) NULL,
 logradouro VARCHAR(160) NOT NULL,
 numero VARCHAR(20) NULL,
 complemento VARCHAR(100) NULL,
 cidade VARCHAR(100) NOT NULL,
 uf CHAR(2) NOT NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE transportadores (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(150) NOT NULL,
 documento VARCHAR(20) NULL,
 telefone VARCHAR(30) NULL,
 email VARCHAR(150) NULL,
 veiculo VARCHAR(100) NULL,
 placa VARCHAR(10) NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE fretes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 data_frete DATE NOT NULL,
 transportador_id INT NOT NULL,
 origem_id INT NOT NULL,
 destino_id INT NOT NULL,
 status ENUM('Pendente','Em transporte','Entregue') NOT NULL DEFAULT 'Pendente',
 observacoes TEXT NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_frete_transportador FOREIGN KEY (transportador_id) REFERENCES transportadores(id) ON DELETE RESTRICT,
 CONSTRAINT fk_frete_origem FOREIGN KEY (origem_id) REFERENCES enderecos(id) ON DELETE RESTRICT,
 CONSTRAINT fk_frete_destino FOREIGN KEY (destino_id) REFERENCES enderecos(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE frete_produtos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 frete_id INT NOT NULL,
 produto_id INT NOT NULL,
 quantidade INT NOT NULL DEFAULT 1,
 CONSTRAINT fk_fp_frete FOREIGN KEY (frete_id) REFERENCES fretes(id) ON DELETE CASCADE,
 CONSTRAINT fk_fp_produto FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE RESTRICT,
 UNIQUE KEY uk_frete_produto (frete_id, produto_id)
) ENGINE=InnoDB;
