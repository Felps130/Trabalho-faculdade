<?php
$pageTitle='Editar endereço';require_once __DIR__.'/../config/database.php';$id=(int)($_GET['id']??0);$s=$pdo->prepare("SELECT * FROM enderecos WHERE id=?");$s->execute([$id]);$address=$s->fetch();if(!$address)exit('Endereço não encontrado.');
if($_SERVER['REQUEST_METHOD']==='POST'){$s=$pdo->prepare("UPDATE enderecos SET identificacao=?,tipo=?,cep=?,logradouro=?,numero=?,complemento=?,cidade=?,uf=? WHERE id=?");$s->execute([post('identificacao'),post('tipo'),post('cep')?:null,post('logradouro'),post('numero')?:null,post('complemento')?:null,post('cidade'),strtoupper(post('uf')),$id]);session_start();flash('Endereço atualizado.');redirect('index.php');}
require_once __DIR__.'/../includes/header.php';require __DIR__.'/_form.php';require_once __DIR__.'/../includes/footer.php';
