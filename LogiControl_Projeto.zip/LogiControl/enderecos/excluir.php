<?php
require_once __DIR__.'/../config/database.php';$id=(int)($_GET['id']??0);
try{$s=$pdo->prepare("DELETE FROM enderecos WHERE id=?");$s->execute([$id]);session_start();flash('Endereço excluído.');}
catch(PDOException $e){session_start();flash('Não foi possível excluir: endereço utilizado em frete.','warning');}
redirect('index.php');
