<?php
$pageTitle='Endereços'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/header.php';
$rows=$pdo->query("SELECT * FROM enderecos ORDER BY id DESC")->fetchAll(); ?>
<div class="page-heading"><div><h1 class="h3 mb-1">Endereços</h1><p class="text-secondary mb-0">Cadastre origens e destinos para os fretes.</p></div><a class="btn btn-primary" href="cadastrar.php">+ Novo endereço</a></div>
<div class="card p-3"><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Identificação</th><th>Tipo</th><th>Cidade/UF</th><th>CEP</th><th>Ações</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?=e($r['identificacao'])?></td><td><?=e($r['tipo'])?></td><td><?=e($r['cidade'])?> / <?=e($r['uf'])?></td><td><?=e($r['cep'])?></td><td><a class="btn btn-sm btn-outline-primary" href="editar.php?id=<?=$r['id']?>">Editar</a> <a class="btn btn-sm btn-outline-danger" data-confirm="Excluir este endereço?" href="excluir.php?id=<?=$r['id']?>">Excluir</a></td></tr><?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="5" class="empty-state">Nenhum endereço cadastrado.</td></tr><?php endif; ?></tbody></table></div></div>
<?php require_once __DIR__.'/../includes/footer.php'; ?>
