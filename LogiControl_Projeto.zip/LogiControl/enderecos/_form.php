<div class="page-heading"><div><h1 class="h3 mb-1"><?=isset($address)?'Editar endereço':'Cadastrar endereço'?></h1><p class="text-secondary mb-0">Informe os dados do local.</p></div><a class="btn btn-outline-secondary" href="index.php">Voltar</a></div>
<div class="card p-4"><form method="post"><div class="row g-3">
<div class="col-md-6"><label class="form-label required">Identificação</label><input class="form-control" name="identificacao" required value="<?=e($address['identificacao']??'')?>"></div>
<div class="col-md-3"><label class="form-label required">Tipo</label><select class="form-select" name="tipo" required><?php foreach(['Origem','Destino','Ambos'] as $v):?><option <?=($address['tipo']??'')===$v?'selected':''?>><?=$v?></option><?php endforeach;?></select></div>
<div class="col-md-3"><label class="form-label">CEP</label><input class="form-control" name="cep" value="<?=e($address['cep']??'')?>"></div>
<div class="col-md-6"><label class="form-label required">Logradouro</label><input class="form-control" name="logradouro" required value="<?=e($address['logradouro']??'')?>"></div>
<div class="col-md-2"><label class="form-label">Número</label><input class="form-control" name="numero" value="<?=e($address['numero']??'')?>"></div>
<div class="col-md-4"><label class="form-label">Complemento</label><input class="form-control" name="complemento" value="<?=e($address['complemento']??'')?>"></div>
<div class="col-md-4"><label class="form-label required">Cidade</label><input class="form-control" name="cidade" required value="<?=e($address['cidade']??'')?>"></div>
<div class="col-md-2"><label class="form-label required">UF</label><input class="form-control text-uppercase" name="uf" required maxlength="2" value="<?=e($address['uf']??'')?>"></div>
<div class="col-12"><button class="btn btn-primary">Salvar endereço</button></div>
</div></form></div>
