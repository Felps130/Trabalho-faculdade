<?php
$pageTitle='Novo endereço'; require_once __DIR__.'/../config/database.php';
if($_SERVER['REQUEST_METHOD']==='POST'){$s=$pdo->prepare("INSERT INTO enderecos(identificacao,tipo,cep,logradouro,numero,complemento,cidade,uf) VALUES(?,?,?,?,?,?,?,?)");$s->execute([post('identificacao'),post('tipo'),post('cep')?:null,post('logradouro'),post('numero')?:null,post('complemento')?:null,post('cidade'),strtoupper(post('uf'))]);session_start();flash('Endereço cadastrado.');redirect('index.php');}
require_once __DIR__.'/../includes/header.php';require __DIR__.'/_form.php';require_once __DIR__.'/../includes/footer.php';
