# LogiControl – Gerenciador Logístico

Projeto acadêmico desenvolvido para a Atividade Prática Orientada da disciplina **Fundamentos de Programação para Internet**.

## Objetivo
Aplicação web para organizar produtos, endereços, transportadores e fretes. Um frete relaciona um transportador, um endereço de origem, um destino e um ou mais produtos.

## Tecnologias
- PHP 8+
- MySQL / MariaDB
- PDO com Prepared Statements
- HTML5, CSS3 e JavaScript
- Bootstrap 5.3
- XAMPP
- Git e GitHub

## Funcionalidades
- Dashboard com totais e fretes recentes.
- Cadastro, listagem, edição e exclusão de produtos.
- Cadastro, listagem, edição e exclusão de endereços.
- Cadastro, listagem, edição e exclusão de transportadores.
- Geração de fretes com vários produtos e quantidades.
- Relatório filtrado por dia com exportação CSV.

## Instalação local (XAMPP)
1. Copie a pasta `LogiControl` para `C:\xampp\htdocs\`.
2. Abra o painel do XAMPP e inicie Apache e MySQL.
3. Acesse `http://localhost/phpmyadmin`.
4. Importe o arquivo `database.sql`.
5. Confira as credenciais em `config/database.php` (padrão XAMPP: usuário `root`, senha vazia).
6. Acesse `http://localhost/LogiControl/`.

## Fluxo sugerido de teste
1. Cadastre dois endereços (por exemplo, origem e destino).
2. Cadastre um transportador.
3. Cadastre dois ou mais produtos.
4. Gere um frete selecionando o transportador, origem, destino e os produtos.
5. Abra Relatórios, escolha a data do frete e baixe o CSV.

## Estrutura
- `config/`: conexão PDO.
- `includes/`: cabeçalho, rodapé e funções comuns.
- `produtos/`, `enderecos/`, `transportadores/`: módulos de cadastro.
- `fretes/`: geração, listagem e relatório.
- `assets/`: CSS e JavaScript.
- `database.sql`: estrutura relacional.

## Modelo de dados
- Um transportador pode estar relacionado a vários fretes.
- Cada frete possui uma origem e um destino.
- A relação entre fretes e produtos é muitos-para-muitos, implementada pela tabela `frete_produtos`, que também registra a quantidade.

## Segurança e boas práticas
- Consultas ao banco feitas com PDO e parâmetros preparados.
- Saídas apresentadas na interface escapadas com `htmlspecialchars`.
- Chaves estrangeiras protegem relacionamentos e impedem exclusões que deixariam fretes inconsistentes.

## Observações
A aplicação é uma base acadêmica funcional para execução local. Antes de publicar em hospedagem real, configure credenciais seguras, autenticação, proteção CSRF, validações adicionais e política de acesso.

## Referências
- PHP. *Manual do PHP*. https://www.php.net/manual/pt_BR/
- Bootstrap. *Documentação Bootstrap 5*. https://getbootstrap.com/docs/5.3/
- W3Schools. *HTML, CSS, JavaScript, PHP e SQL*. https://www.w3schools.com/
- MySQL. *MySQL 8.0 Reference Manual*. https://dev.mysql.com/doc/
- CHACON, Scott; STRAUB, Ben. *Pro Git*. https://git-scm.com/book/pt-br/v2
