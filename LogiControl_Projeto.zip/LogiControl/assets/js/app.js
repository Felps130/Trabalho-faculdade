document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', ev => {
      if (!confirm(el.dataset.confirm || 'Confirma esta operação?')) ev.preventDefault();
    });
  });
  const add = document.getElementById('add-product-row');
  const list = document.getElementById('product-rows');
  if (add && list) {
    add.addEventListener('click', () => {
      const first = list.querySelector('.product-row');
      const clone = first.cloneNode(true);
      clone.querySelectorAll('select,input').forEach(el => { el.value = ''; });
      list.appendChild(clone);
    });
    list.addEventListener('click', ev => {
      if (ev.target.classList.contains('remove-row')) {
        if (list.querySelectorAll('.product-row').length > 1) ev.target.closest('.product-row').remove();
      }
    });
  }
});
