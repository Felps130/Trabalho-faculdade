<?php
$pageTitle='Transportadores';require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/header.php';$rows=$pdo->query("SELECT * FROM transportadores ORDER BY id DESC")->fetchAll();?>
<div class="page-heading"><div><h1 class="h3 mb-1">Transportadores</h1><p class="text-secondary mb-0">Gerencie motoristas e empresas responsáveis pelo transporte.</p></div><a class="btn btn-primary" href="cadastrar.php">+ Novo transportador</a></div>
<div class="card p-3"><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Nome</th><th>Documento</th><th>Telefone</th><th>Veículo</th><th>Ações</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr><td><?=e($r['nome'])?></td><td><?=e($r['documento'])?></td><td><?=e($r['telefone'])?></td><td><?=e($r['veiculo'])?></td><td><a class="btn btn-sm btn-outline-primary" href="editar.php?id=<?=$r['id']?>">Editar</a> <a class="btn btn-sm btn-outline-danger" data-confirm="Excluir transportador?" href="excluir.php?id=<?=$r['id']?>">Excluir</a></td></tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="5" class="empty-state">Nenhum transportador cadastrado.</td></tr><?php endif;?></tbody></table></div></div>
<?php require_once __DIR__.'/../includes/footer.php';?>
