<div class="page-heading"><div><h1 class="h3 mb-1"><?=isset($carrier)?'Editar transportador':'Cadastrar transportador'?></h1><p class="text-secondary mb-0">Dados do responsável pelo transporte.</p></div><a class="btn btn-outline-secondary" href="index.php">Voltar</a></div>
<div class="card p-4"><form method="post"><div class="row g-3">
<div class="col-md-6"><label class="form-label required">Nome / Razão social</label><input class="form-control" name="nome" required value="<?=e($carrier['nome']??'')?>"></div>
<div class="col-md-3"><label class="form-label">CPF / CNPJ</label><input class="form-control" name="documento" value="<?=e($carrier['documento']??'')?>"></div>
<div class="col-md-3"><label class="form-label">Telefone</label><input class="form-control" name="telefone" value="<?=e($carrier['telefone']??'')?>"></div>
<div class="col-md-4"><label class="form-label">E-mail</label><input class="form-control" type="email" name="email" value="<?=e($carrier['email']??'')?>"></div>
<div class="col-md-4"><label class="form-label">Veículo</label><input class="form-control" name="veiculo" value="<?=e($carrier['veiculo']??'')?>"></div>
<div class="col-md-4"><label class="form-label">Placa</label><input class="form-control" name="placa" value="<?=e($carrier['placa']??'')?>"></div>
<div class="col-12"><button class="btn btn-primary">Salvar transportador</button></div>
</div></form></div>
