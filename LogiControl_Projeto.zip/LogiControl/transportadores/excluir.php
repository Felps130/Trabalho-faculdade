<?php
require_once __DIR__.'/../config/database.php';$id=(int)($_GET['id']??0);
try{$s=$pdo->prepare("DELETE FROM transportadores WHERE id=?");$s->execute([$id]);session_start();flash('Transportador excluído.');}
catch(PDOException $e){session_start();flash('Não foi possível excluir: transportador vinculado a frete.','warning');}
redirect('index.php');
