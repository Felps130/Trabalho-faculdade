<?php
$pageTitle='Editar transportador';require_once __DIR__.'/../config/database.php';$id=(int)($_GET['id']??0);$s=$pdo->prepare("SELECT * FROM transportadores WHERE id=?");$s->execute([$id]);$carrier=$s->fetch();if(!$carrier)exit('Transportador não encontrado.');
if($_SERVER['REQUEST_METHOD']==='POST'){$s=$pdo->prepare("UPDATE transportadores SET nome=?,documento=?,telefone=?,email=?,veiculo=?,placa=? WHERE id=?");$s->execute([post('nome'),post('documento')?:null,post('telefone')?:null,post('email')?:null,post('veiculo')?:null,post('placa')?:null,$id]);session_start();flash('Transportador atualizado.');redirect('index.php');}
require_once __DIR__.'/../includes/header.php';require __DIR__.'/_form.php';require_once __DIR__.'/../includes/footer.php';
