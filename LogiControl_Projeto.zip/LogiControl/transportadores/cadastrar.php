<?php
$pageTitle='Novo transportador';require_once __DIR__.'/../config/database.php';
if($_SERVER['REQUEST_METHOD']==='POST'){$s=$pdo->prepare("INSERT INTO transportadores(nome,documento,telefone,email,veiculo,placa) VALUES(?,?,?,?,?,?)");$s->execute([post('nome'),post('documento')?:null,post('telefone')?:null,post('email')?:null,post('veiculo')?:null,post('placa')?:null]);session_start();flash('Transportador cadastrado.');redirect('index.php');}
require_once __DIR__.'/../includes/header.php';require __DIR__.'/_form.php';require_once __DIR__.'/../includes/footer.php';
