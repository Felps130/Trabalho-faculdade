<?php
$isEdit = isset($product);
?>
<div class="page-heading"><div><h1 class="h3 mb-1"><?= $isEdit?'Editar produto':'Cadastrar produto' ?></h1><p class="text-secondary mb-0">Informe os dados do item.</p></div><a class="btn btn-outline-secondary" href="index.php">Voltar</a></div>
<div class="card p-4"><form method="post">
<div class="row g-3">
<div class="col-md-6"><label class="form-label required">Nome</label><input class="form-control" name="nome" required maxlength="120" value="<?=e($product['nome']??'')?>"></div>
<div class="col-md-3"><label class="form-label">SKU / Código</label><input class="form-control" name="sku" maxlength="40" value="<?=e($product['sku']??'')?>"></div>
<div class="col-md-3"><label class="form-label">Categoria</label><input class="form-control" name="categoria" maxlength="80" value="<?=e($product['categoria']??'')?>"></div>
<div class="col-md-3"><label class="form-label">Peso (kg)</label><input class="form-control" type="number" min="0" step="0.001" name="peso" value="<?=e($product['peso']??'')?>"></div>
<div class="col-md-3"><label class="form-label">Quantidade em estoque</label><input class="form-control" type="number" min="0" name="estoque" value="<?=e($product['estoque']??'0')?>"></div>
<div class="col-12"><label class="form-label">Descrição</label><textarea class="form-control" name="descricao" rows="3"><?=e($product['descricao']??'')?></textarea></div>
<div class="col-12"><button class="btn btn-primary">Salvar produto</button></div>
</div></form></div>
