<?php
require_once __DIR__.'/../config/database.php'; $id=(int)($_GET['id']??0);
try{$s=$pdo->prepare("DELETE FROM produtos WHERE id=?");$s->execute([$id]);session_start();flash('Produto excluído.');}
catch(PDOException $e){session_start();flash('Não foi possível excluir: o produto está vinculado a um frete.','warning');}
redirect('index.php');
