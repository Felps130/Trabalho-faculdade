<?php
$pageTitle='Editar produto'; require_once __DIR__.'/../config/database.php'; $id=(int)($_GET['id']??0);
$s=$pdo->prepare("SELECT * FROM produtos WHERE id=?"); $s->execute([$id]); $product=$s->fetch();
if(!$product){http_response_code(404);exit('Produto não encontrado.');}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $s=$pdo->prepare("UPDATE produtos SET nome=?,sku=?,categoria=?,peso=?,estoque=?,descricao=? WHERE id=?");
 $s->execute([post('nome'),post('sku')?:null,post('categoria')?:null,post('peso')?:0,post('estoque')?:0,post('descricao')?:null,$id]);
 session_start(); flash('Produto atualizado.'); redirect('index.php');
}
require_once __DIR__.'/../includes/header.php'; require __DIR__.'/_form.php'; require_once __DIR__.'/../includes/footer.php';
