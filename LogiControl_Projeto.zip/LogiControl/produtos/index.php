<?php
$pageTitle='Produtos'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/header.php';
$rows=$pdo->query("SELECT * FROM produtos ORDER BY id DESC")->fetchAll(); ?>
<div class="page-heading"><div><h1 class="h3 mb-1">Produtos</h1><p class="text-secondary mb-0">Gerencie os itens transportados.</p></div><a class="btn btn-primary" href="cadastrar.php">+ Novo produto</a></div>
<div class="card p-3"><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Produto</th><th>SKU</th><th>Categoria</th><th>Peso (kg)</th><th>Ações</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?=e($r['nome'])?></td><td><?=e($r['sku'])?></td><td><?=e($r['categoria'])?></td><td><?=e($r['peso'])?></td><td><a class="btn btn-sm btn-outline-primary" href="editar.php?id=<?=$r['id']?>">Editar</a> <a class="btn btn-sm btn-outline-danger" data-confirm="Excluir este produto?" href="excluir.php?id=<?=$r['id']?>">Excluir</a></td></tr><?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="5" class="empty-state">Nenhum produto cadastrado.</td></tr><?php endif; ?></tbody></table></div></div>
<?php require_once __DIR__.'/../includes/footer.php'; ?>
