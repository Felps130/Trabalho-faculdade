<?php
$pageTitle='Novo produto'; require_once __DIR__.'/../config/database.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $s=$pdo->prepare("INSERT INTO produtos(nome,sku,categoria,peso,estoque,descricao) VALUES(?,?,?,?,?,?)");
 $s->execute([post('nome'),post('sku')?:null,post('categoria')?:null,post('peso')?:0,post('estoque')?:0,post('descricao')?:null]);
 session_start(); flash('Produto cadastrado com sucesso.'); redirect('index.php');
}
require_once __DIR__.'/../includes/header.php'; require __DIR__.'/_form.php'; require_once __DIR__.'/../includes/footer.php';
