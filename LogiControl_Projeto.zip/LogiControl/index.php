<?php
$pageTitle = 'Dashboard';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/header.php';
$counts = [];
foreach (['produtos'=>'Produtos cadastrados','enderecos'=>'Endereços cadastrados','transportadores'=>'Transportadores','fretes'=>'Fretes registrados'] as $table=>$label) {
    $counts[$label] = (int)$pdo->query("SELECT COUNT(*) FROM {$table}")->fetchColumn();
}
$recent = $pdo->query("SELECT f.id, f.data_frete, f.status, t.nome AS transportador, ao.cidade AS origem, ad.cidade AS destino
 FROM fretes f JOIN transportadores t ON t.id=f.transportador_id
 JOIN enderecos ao ON ao.id=f.origem_id JOIN enderecos ad ON ad.id=f.destino_id
 ORDER BY f.id DESC LIMIT 5")->fetchAll();
?>
<div class="page-heading"><div><span class="brand-mark mb-2">LC</span><h1 class="h3 mb-1">Visão geral</h1><p class="text-secondary mb-0">Acompanhe os cadastros e as operações logísticas.</p></div><a class="btn btn-primary" href="fretes/cadastrar.php">+ Novo frete</a></div>
<div class="row g-3 mb-4">
<?php foreach($counts as $label=>$value): ?>
<div class="col-12 col-sm-6 col-xl-3"><div class="card stat-card"><div class="stat-label"><?= e($label) ?></div><div class="stat-value"><?= $value ?></div></div></div>
<?php endforeach; ?>
</div>
<div class="card p-3 p-lg-4"><div class="d-flex justify-content-between align-items-center mb-3"><h2 class="h5 mb-0">Fretes recentes</h2><a href="fretes/index.php" class="text-decoration-none">Ver todos</a></div>
<div class="table-responsive"><table class="table align-middle"><thead><tr><th>Código</th><th>Data</th><th>Transportador</th><th>Rota</th><th>Status</th></tr></thead><tbody>
<?php if(!$recent): ?><tr><td colspan="5" class="empty-state">Nenhum frete cadastrado ainda.</td></tr><?php endif; ?>
<?php foreach($recent as $r): ?><tr><td>#<?= (int)$r['id'] ?></td><td><?= e(date('d/m/Y',strtotime($r['data_frete']))) ?></td><td><?= e($r['transportador']) ?></td><td><?= e($r['origem']) ?> → <?= e($r['destino']) ?></td><td><span class="badge text-bg-<?= $r['status']==='Entregue'?'success':'primary' ?>"><?= e($r['status']) ?></span></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
