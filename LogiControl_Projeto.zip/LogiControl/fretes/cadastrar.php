<?php
$pageTitle='Gerar frete';require_once __DIR__.'/../config/database.php';
$products=$pdo->query("SELECT id,nome,sku FROM produtos ORDER BY nome")->fetchAll();
$addresses=$pdo->query("SELECT id,identificacao,cidade,uf,tipo FROM enderecos ORDER BY identificacao")->fetchAll();
$carriers=$pdo->query("SELECT id,nome FROM transportadores ORDER BY nome")->fetchAll();
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $productIds=$_POST['produto_id']??[]; $quantities=$_POST['quantidade']??[];
 if(!$productIds || !post('transportador_id') || !post('origem_id') || !post('destino_id')) $error='Selecione transportador, origem, destino e pelo menos um produto.';
 elseif(post('origem_id')===post('destino_id')) $error='A origem e o destino precisam ser diferentes.';
 else {
  try{
   $pdo->beginTransaction();
   $s=$pdo->prepare("INSERT INTO fretes(data_frete,transportador_id,origem_id,destino_id,status,observacoes) VALUES(?,?,?,?,?,?)");
   $s->execute([post('data_frete')?:date('Y-m-d'),(int)post('transportador_id'),(int)post('origem_id'),(int)post('destino_id'),post('status')?:'Pendente',post('observacoes')?:null]);
   $freteId=(int)$pdo->lastInsertId(); $item=$pdo->prepare("INSERT INTO frete_produtos(frete_id,produto_id,quantidade) VALUES(?,?,?)");
   foreach($productIds as $i=>$pid){$qty=max(1,(int)($quantities[$i]??1));$item->execute([$freteId,(int)$pid,$qty]);}
   $pdo->commit();session_start();flash('Frete gerado com sucesso.');redirect('index.php');
  }catch(Throwable $ex){if($pdo->inTransaction())$pdo->rollBack();$error='Não foi possível gerar o frete. Confira os dados selecionados.';}
 }
}
require_once __DIR__.'/../includes/header.php';
?>
<div class="page-heading"><div><h1 class="h3 mb-1">Gerar frete</h1><p class="text-secondary mb-0">Relacione rota, transportador e um ou mais produtos.</p></div><a class="btn btn-outline-secondary" href="index.php">Voltar</a></div>
<?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
<?php if(!$products||!$addresses||!$carriers):?><div class="alert alert-warning">Antes de gerar um frete, cadastre ao menos um produto, dois endereços e um transportador.</div><?php endif;?>
<div class="card p-4"><form method="post">
<div class="row g-3">
<div class="col-md-3"><label class="form-label required">Data do frete</label><input type="date" class="form-control" name="data_frete" required value="<?=e($_POST['data_frete']??date('Y-m-d'))?>"></div>
<div class="col-md-3"><label class="form-label required">Transportador</label><select class="form-select" name="transportador_id" required><option value="">Selecione</option><?php foreach($carriers as $c):?><option value="<?=$c['id']?>"><?=e($c['nome'])?></option><?php endforeach;?></select></div>
<div class="col-md-3"><label class="form-label required">Origem</label><select class="form-select" name="origem_id" required><option value="">Selecione</option><?php foreach($addresses as $a):?><option value="<?=$a['id']?>"><?=e($a['identificacao'].' - '.$a['cidade'].'/'.$a['uf'])?></option><?php endforeach;?></select></div>
<div class="col-md-3"><label class="form-label required">Destino</label><select class="form-select" name="destino_id" required><option value="">Selecione</option><?php foreach($addresses as $a):?><option value="<?=$a['id']?>"><?=e($a['identificacao'].' - '.$a['cidade'].'/'.$a['uf'])?></option><?php endforeach;?></select></div>
<div class="col-12"><div class="d-flex justify-content-between align-items-center mb-2"><label class="form-label mb-0 required">Produtos transportados</label><button type="button" class="btn btn-sm btn-outline-primary" id="add-product-row">+ Adicionar produto</button></div>
<div id="product-rows"><div class="row g-2 product-row mb-2"><div class="col-md-9"><select class="form-select" name="produto_id[]" required><option value="">Selecione um produto</option><?php foreach($products as $p):?><option value="<?=$p['id']?>"><?=e($p['nome'].($p['sku']?' - '.$p['sku']:''))?></option><?php endforeach;?></select></div><div class="col-md-2"><input class="form-control" type="number" min="1" name="quantidade[]" value="1" required></div><div class="col-md-1"><button type="button" class="btn btn-outline-danger w-100 remove-row" aria-label="Remover">×</button></div></div></div>
</div>
<div class="col-md-4"><label class="form-label">Status</label><select class="form-select" name="status"><option>Pendente</option><option>Em transporte</option><option>Entregue</option></select></div>
<div class="col-12"><label class="form-label">Observações</label><textarea class="form-control" name="observacoes" rows="2"></textarea></div>
<div class="col-12"><button class="btn btn-primary" <?=(!$products||!$addresses||!$carriers)?'disabled':''?>>Salvar frete</button></div>
</div></form></div>
<?php require_once __DIR__.'/../includes/footer.php';?>
