<?php
require_once __DIR__.'/../config/database.php';
$dia=$_GET['dia']??date('Y-m-d');
$s=$pdo->prepare("SELECT f.id,f.data_frete,f.status,t.nome transportador,ao.identificacao origem,ad.identificacao destino,GROUP_CONCAT(CONCAT(p.nome,' (',fp.quantidade,')') SEPARATOR '; ') produtos FROM fretes f JOIN transportadores t ON t.id=f.transportador_id JOIN enderecos ao ON ao.id=f.origem_id JOIN enderecos ad ON ad.id=f.destino_id JOIN frete_produtos fp ON fp.frete_id=f.id JOIN produtos p ON p.id=fp.produto_id WHERE f.data_frete=? GROUP BY f.id ORDER BY f.id");
$s->execute([$dia]);$rows=$s->fetchAll();
if(isset($_GET['download'])){
 header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="relatorio-fretes-'.$dia.'.csv"');
 $out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,['Código','Data','Transportador','Origem','Destino','Produtos','Status'],';');
 foreach($rows as $r)fputcsv($out,[$r['id'],$r['data_frete'],$r['transportador'],$r['origem'],$r['destino'],$r['produtos'],$r['status']],';');fclose($out);exit;
}
$pageTitle='Relatório de fretes';require_once __DIR__.'/../includes/header.php';?>
<div class="page-heading"><div><h1 class="h3 mb-1">Relatório diário de fretes</h1><p class="text-secondary mb-0">Consulte e exporte as operações de uma data específica.</p></div></div>
<div class="card p-3 mb-3"><form class="row g-2 align-items-end"><div class="col-sm-4"><label class="form-label">Data</label><input class="form-control" type="date" name="dia" value="<?=e($dia)?>"></div><div class="col-auto"><button class="btn btn-primary">Consultar</button></div><div class="col-auto"><a class="btn btn-outline-success" href="?dia=<?=e($dia)?>&download=1">Baixar CSV</a></div></form></div>
<div class="card p-3"><div class="mb-3 fw-semibold"><?=count($rows)?> frete(s) encontrado(s) em <?=e(date('d/m/Y',strtotime($dia)))?></div><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Código</th><th>Transportador</th><th>Origem</th><th>Destino</th><th>Produtos e quantidades</th><th>Status</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr><td>#<?=$r['id']?></td><td><?=e($r['transportador'])?></td><td><?=e($r['origem'])?></td><td><?=e($r['destino'])?></td><td><?=e($r['produtos'])?></td><td><?=e($r['status'])?></td></tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="6" class="empty-state">Nenhum frete encontrado para esta data.</td></tr><?php endif;?></tbody></table></div></div>
<?php require_once __DIR__.'/../includes/footer.php';?>
