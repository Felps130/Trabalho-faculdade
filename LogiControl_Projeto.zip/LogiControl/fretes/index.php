<?php
$pageTitle='Fretes';require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/header.php';
$rows=$pdo->query("SELECT f.*,t.nome transportador,ao.cidade origem,ad.cidade destino,(SELECT COUNT(*) FROM frete_produtos fp WHERE fp.frete_id=f.id) total_produtos FROM fretes f JOIN transportadores t ON t.id=f.transportador_id JOIN enderecos ao ON ao.id=f.origem_id JOIN enderecos ad ON ad.id=f.destino_id ORDER BY f.id DESC")->fetchAll();?>
<div class="page-heading"><div><h1 class="h3 mb-1">Fretes</h1><p class="text-secondary mb-0">Crie e acompanhe as operações de transporte.</p></div><a class="btn btn-primary" href="cadastrar.php">+ Gerar frete</a></div>
<div class="card p-3"><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Código</th><th>Data</th><th>Transportador</th><th>Origem → Destino</th><th>Produtos</th><th>Status</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr><td>#<?=$r['id']?></td><td><?=e(date('d/m/Y',strtotime($r['data_frete'])))?></td><td><?=e($r['transportador'])?></td><td><?=e($r['origem'])?> → <?=e($r['destino'])?></td><td><?=$r['total_produtos']?></td><td><span class="badge text-bg-<?= $r['status']==='Entregue'?'success':'primary' ?>"><?=e($r['status'])?></span></td></tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="6" class="empty-state">Nenhum frete registrado.</td></tr><?php endif;?></tbody></table></div></div>
<?php require_once __DIR__.'/../includes/footer.php';?>
