<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/functions.php';
$pageTitle = $pageTitle ?? 'Painel';
$current = basename($_SERVER['PHP_SELF']);
$pathDepth = substr_count(trim($_SERVER['SCRIPT_NAME'], '/'), '/');
$base = $pathDepth > 1 ? '../' : ''; 
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle) ?> | LogiControl</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= $base ?>assets/css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark app-navbar">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold" href="<?= $base ?>index.php">LogiControl</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="mainNav">
      <div class="navbar-nav ms-auto">
        <a class="nav-link" href="<?= $base ?>index.php">Dashboard</a>
        <a class="nav-link" href="<?= $base ?>produtos/index.php">Produtos</a>
        <a class="nav-link" href="<?= $base ?>enderecos/index.php">Endereços</a>
        <a class="nav-link" href="<?= $base ?>transportadores/index.php">Transportadores</a>
        <a class="nav-link" href="<?= $base ?>fretes/index.php">Fretes</a>
        <a class="nav-link" href="<?= $base ?>fretes/relatorio.php">Relatórios</a>
      </div>
    </div>
  </div>
</nav>
<main class="container-fluid px-4 py-4">
<?php show_flash(); ?>
