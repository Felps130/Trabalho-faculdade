</main>
<footer class="text-center text-secondary py-4 small">LogiControl · Gerenciador Logístico acadêmico</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= $base ?>assets/js/app.js"></script>
</body></html>
